//
// Created by robbe on 3/12/22.
//
#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
